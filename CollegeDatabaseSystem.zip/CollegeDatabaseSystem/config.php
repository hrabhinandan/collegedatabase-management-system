<?php


$databaseHost = 'localhost';
$databaseName = 'collegedatabase';
$databaseUsername = 'root';
$databasePassword = '';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
?>